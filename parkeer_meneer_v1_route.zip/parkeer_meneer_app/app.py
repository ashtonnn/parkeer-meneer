from flask import Flask, jsonify, send_from_directory, request
from pathlib import Path
import requests, xml.etree.ElementTree as ET, time, threading, re
ROOT=Path(__file__).resolve().parent
app=Flask(__name__,static_folder=str(ROOT),static_url_path='')
WFS='https://diensten.rotterdam.nl/arcgis/services/SB_Infra/Parkeervoorzieningen/MapServer/WFSServer'
HEADERS={'User-Agent':'ParkeerMeneerCityverse/1.0 (educational project; public geographic metadata)'}
CACHE={'time':0,'features':[],'error':None}; LOCK=threading.Lock()
@app.get('/')
def home():return send_from_directory(ROOT,'index.html')
@app.get('/api/health')
def health():return jsonify(status='ok',data='Rotterdam WFS metadata',occupancy='simulated')
def pairs(geometry):
 def walk(a):
  if isinstance(a,list):
   if len(a)>=2 and all(isinstance(v,(int,float)) for v in a[:2]):yield a[:2]
   else:
    for v in a:yield from walk(v)
 return list(walk(geometry.get('coordinates',[])))
def center(geom):
 p=pairs(geom)
 if not p:return None
 # WFS coordinates can be lat/lon or lon/lat depending on axis order
 a,b=p[0]; flip= 51<a<52.2 and 3.7<b<5
 if flip:p=[(b,a) for a,b in p]
 valid=[(x,y) for x,y in p if 3.7<x<5 and 51.7<y<52.2]
 if not valid:return None
 return [sum(v[1] for v in valid)/len(valid),sum(v[0] for v in valid)/len(valid)]
def fetch_parking():
 cap=requests.get(WFS,params={'service':'WFS','request':'GetCapabilities','version':'2.0.0'},headers=HEADERS,timeout=12)
 cap.raise_for_status(); root=ET.fromstring(cap.content)
 types=[n.text for n in root.findall('.//{*}FeatureType/{*}Name') if n.text]
 if not types:raise ValueError('Geen WFS-lagen gevonden')
 out=[]
 for typ in types[:4]:
  params={'service':'WFS','version':'2.0.0','request':'GetFeature','typeNames':typ,'count':400,'outputFormat':'application/json','srsName':'EPSG:4326'}
  r=requests.get(WFS,params=params,headers=HEADERS,timeout=18)
  if not r.ok or 'json' not in r.headers.get('content-type','').lower():continue
  for f in r.json().get('features',[]):
   c=center(f.get('geometry') or {})
   if not c:continue
   props=f.get('properties') or {}
   name=next((str(v) for k,v in props.items() if any(w in k.lower() for w in ('straat','naam','name','omschrijving')) and v), 'Parkeervoorziening')
   out.append({'id':str(f.get('id') or len(out)),'name':name[:95],'lat':c[0],'lon':c[1],'source':'Gemeente Rotterdam WFS','kind':f.get('geometry',{}).get('type'),'properties':props})
 if not out:raise ValueError('WFS gaf geen bruikbare parkeerlocaties terug; controleer de service en objecttypen')
 return out[:500]
@app.get('/api/parking')
def parking():
 with LOCK:
  if time.time()-CACHE['time']>1800:
   try:CACHE.update(time=time.time(),features=fetch_parking(),error=None)
   except Exception as e:CACHE.update(time=time.time(),features=[],error=str(e)[:240])
 return jsonify(mode='real_locations' if CACHE['features'] else 'unavailable',features=CACHE['features'],error=CACHE['error'],occupancy='simulated')
@app.get('/api/search')
def search():
 q=request.args.get('q','').strip()[:120]
 if len(q)<2:return jsonify(results=[])
 try:
  r=requests.get('https://nominatim.openstreetmap.org/search',params={'q':q+', Rotterdam, Nederland','format':'json','limit':7,'addressdetails':1,'polygon_geojson':1,'countrycodes':'nl'},headers=HEADERS,timeout=12)
  r.raise_for_status();results=[]
  for x in r.json():
   lat=float(x['lat']);lon=float(x['lon'])
   if 51.7<lat<52.2 and 3.7<lon<5:results.append({'name':x.get('display_name',''),'lat':lat,'lon':lon,'geometry':x.get('geojson'),'type':x.get('type')})
  return jsonify(results=results)
 except Exception as e:return jsonify(results=[],error=str(e)[:180]),502
if __name__=='__main__':app.run(host='0.0.0.0',port=5000,debug=False)
