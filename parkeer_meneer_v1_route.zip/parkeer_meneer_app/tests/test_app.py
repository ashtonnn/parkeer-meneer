import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import app,center
class Tests(unittest.TestCase):
 def test_home(self):
  r=app.test_client().get('/');self.assertEqual(r.status_code,200);self.assertIn(b'Parkeer Meneer',r.data)
 def test_health(self):self.assertEqual(app.test_client().get('/api/health').json['status'],'ok')
 def test_polygon_center(self):self.assertEqual(center({'coordinates':[[[4.4,51.9],[4.6,51.9],[4.5,52.0]]]}),[51.93333333333334,4.5])
if __name__=='__main__':unittest.main()
