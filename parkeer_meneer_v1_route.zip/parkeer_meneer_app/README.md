# Parkeer Meneer – Cityverse

Mobielvriendelijke parkeerkaart voor Rotterdam, zonder AI. Kaart via OpenStreetMap/Leaflet. Straat zoeken via OpenStreetMap Nominatim; waar mogelijk wordt de straatgeometrie blauw gemarkeerd. Een geselecteerde straat kan via Waze, Google Maps of Apple Kaarten worden geopend. De route wordt berekend in de gekozen externe navigatie-app.

## Starten op een pc
1. Installeer Python 3.10+.
2. Pak de ZIP uit en open een terminal in de map `parkeer_meneer_app`.
3. Voer `pip install -r requirements.txt` uit.
4. Voer `python app.py` uit.
5. Open `http://localhost:5000` op je laptop.

## Openen op je telefoon
Verbind je telefoon en pc met hetzelfde wifi-netwerk. Zoek het lokale IPv4-adres van je pc (`ipconfig` op Windows). Open op je telefoon `http://PC-IP-ADRES:5000`. Sta de verbinding toe in Windows Firewall als daarom wordt gevraagd. De app draait op 0.0.0.0:5000, maar is niet bedoeld om publiek op internet te zetten zonder extra beveiliging.

## Echte data en beperkingen
De JSON-LD-bestanden in `data/` zijn catalogusmetadata met verwijzingen naar externe dataservices, niet de volledige parkeerbezetting. De backend probeert de Rotterdam WFS-service `Parkeervoorzieningen` te raadplegen. Als die onbereikbaar is of geen geschikte objecten levert, toont de app expliciet voorbeeldlocaties. Geo-objecten uit de WFS zijn niet per se individuele parkeervakken. Vrij/bezet is altijd gesimuleerd. Straatselectie en route zijn afhankelijk van OpenStreetMap/Nominatim en de externe navigatie-apps. Een straatresultaat kan naar het middelpunt van een straat leiden, niet naar een legaal parkeeradres. Controleer verkeersregels en daadwerkelijke beschikbaarheid.

## Tests
`python -m py_compile app.py` en `python -m unittest discover -s tests`.
